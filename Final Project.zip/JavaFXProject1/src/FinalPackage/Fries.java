package FinalPackage;

import javafx.application.Application;

public class Fries {
	char type = 'A';
	String description = "";
	int quantity = 1;
	double price = 0.0;
	public char getType() {
		return type;
	}
	public void setType(char type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}

